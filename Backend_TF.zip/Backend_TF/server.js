const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();

// Configuración de MySQL
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "12345678",
    database: "bd_meditel",
});

connection.connect((err) => {
    if (err) {
        console.error("Error de conexión:", err);
        return;
    }
    console.log("Conexión a MySQL establecida");
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Rutas
app.get("/buscar/medico", (req, res) => {

    const nombreMedico = req.query.query;

    connection.query("SELECT id as `value`, concat(nombres,' ', apellidos) as `text` FROM medicos WHERE concat(UPPER(nombres),' ', UPPER(apellidos)) LIKE ? ", [`%${nombreMedico.toUpperCase()}%`], (err, results) => {
        if (err) {
            console.error("Error al ejecutar la consulta:", err);
            res.status(500).json({ error: "Error al obtener usuarios" });
            return;
        }
        res.json(results);
    });
});

app.post("/login", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(200).json({ mensaje: "Se requiere nombre de usuario y contraseña" });
    }

    connection.query("SELECT * FROM usuario WHERE email = ? AND contrasena = ?",
        [username, password], (err, rows) => {
            if (err) {
                console.error("Error al ejecutar la consulta:", err);
                res.status(500).json({ error: "Error al obtener usuarios" });
                return;
            }

            if (rows.length === 0) {
                return res.status(200).json({ mensaje: "Credenciales incorrectas" });
            }

            res.status(200).json({ mensaje: "Inicio de sesión exitoso", usuario: rows[0] });
        }
    );
});


app.post("/registrar", (req, res) => {
    const { nombre, apellidos, tipo_doc, num_doc, celular, fecha_nac, Departamento, Provincia, Distrito, Domicilio, email, contrasena } = req.body;

    connection.query("INSERT INTO usuario (nombre, apellidos, tipo_doc, num_doc, celular, fecha_nac, Departamento, Provincia, Distrito, Domicilio, email, contrasena) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [nombre, apellidos, tipo_doc, num_doc, celular, fecha_nac, Departamento, Provincia, Distrito, Domicilio, email, contrasena], (err, rows) => {
            if (err) {
                console.error("Error al ejecutar la consulta:", err);
                return res.status(500).json({ mensaje: "Error al insertar datos" });
            } else {
                return res.status(200).json({ mensaje: "Datos insertados correctamente" });
            }
        }
    );
});

// Iniciar el servidor
const PORT = process.env.PORT || 8080;
const HOST = '0.0.0.0';

app.listen(PORT, HOST, () => {
    console.log(`Servidor backend corriendo en http://${HOST}:${PORT}`);
});
