package com.upc.example.proyectofinal;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class FragmentTeleConsulta extends Fragment {

    private AutoCompleteTextView autoCompleteTextView;
    private RequestQueue requestQueue;
    private ArrayAdapter<String> adapter;
    private String baseUrl = "http://192.168.1.59:8080/";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.teleconsulta1, container, false);

        autoCompleteTextView = rootView.findViewById(R.id.autocompletemedico);


        // configurarAutoCompleteTextView();
        adapter  = new ArrayAdapter<>(requireContext(), android.R.layout.simple_dropdown_item_1line);

        autoCompleteTextView.setAdapter(adapter);

        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = (String) parent.getItemAtPosition(position);

                showToast("Seleccionado: " + selectedItem);
            }
        });

        requestQueue = Volley.newRequestQueue(requireContext());

        autoCompleteTextView.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                obtenerSugerencias(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) { }

        });


        return rootView;
    }

    private void configurarAutoCompleteTextView() {


    }

    private void obtenerSugerencias(String input) {
        String url = baseUrl + "buscar/medico?query=" + input;

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        List<String> sugerencias = new ArrayList<>();

                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);
                                String text = jsonObject.getString("text");
                                sugerencias.add(text);
                            }

                            adapter.clear();
                            adapter.addAll(sugerencias);
                            adapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        showToast("Error: " + error.getMessage());
                    }
                });



        requestQueue.add(request);
    }
    private void showToast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }
}
