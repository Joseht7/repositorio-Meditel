package com.upc.example.proyectofinal

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        cargarFragmentoGeneral(FragmentLogin())
    }

    fun cambiarFragmentoMain(view: android.view.View){
        val fragment: Fragment = FragmentMain()
        cargarFragmentoGeneral(fragment)
    }

    fun cambiarFragmentoTeleConsulta(view: android.view.View){
        val fragment: Fragment = FragmentTeleConsulta()
        cargarFragmentoGeneral(fragment)
    }

    fun cambiarFragmentoTeleConsulta2(view: android.view.View){
        val fragment: Fragment = FragmentTeleConsulta2()
        cargarFragmentoGeneral(fragment)
    }

    fun cambiarFragmentoRegistroUsuario(view: android.view.View){
        val fragment: Fragment = FragmentRegistroUsuario()
        cargarFragmentoGeneral(fragment)
    }

    fun cambiarFragmentoLogin(view: android.view.View){
        val fragment: Fragment = FragmentLogin()
        cargarFragmentoGeneral(fragment)
    }

    fun regresarMain(view: android.view.View){
        val fragment: Fragment = FragmentMain()
        cargarFragmentoGeneral(fragment)
    }

    private fun cargarFragmentoGeneral(fragment: Fragment){
        val fragmentManager: FragmentManager = supportFragmentManager
        val transaction: FragmentTransaction = fragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment)
        transaction.addToBackStack(null);
        transaction.commit()
    }

    private fun cargarFragmentoTeleConsultaStatus():Boolean{
        return true;
    }


}
