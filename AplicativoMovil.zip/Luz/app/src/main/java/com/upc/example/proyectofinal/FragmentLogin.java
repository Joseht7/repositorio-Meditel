package com.upc.example.proyectofinal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FragmentLogin extends Fragment {

    private EditText editTextEmail, editTextPassword;
    private Button btnLogin;
    private RequestQueue requestQueue;
    private String baseUrl = "http://192.168.1.59:8080/";
    private ProgressBar progressBar;
    private Boolean isAuth = false;
private String mUsername;

public FragmentLogin(){ }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.login, container, false);

        progressBar = rootView.findViewById(R.id.progressBar);
        requestQueue = Volley.newRequestQueue(requireContext());

        editTextEmail = rootView.findViewById(R.id.email_input);
        editTextPassword = rootView.findViewById(R.id.password_input);
        btnLogin = rootView.findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showProgressBar();
                iniciarSesion(v);
            }
        });


        return rootView;
    }

    private void iniciarSesion(View v) {

        String url = baseUrl + "login";

        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("username", email);
            jsonBody.put("password", password);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        hideProgressBar();

                        try {
                            String mensaje = response.getString("mensaje");

                            if(mensaje.equals("Inicio de sesión exitoso")){
                                JSONObject usuario = response.getJSONObject("usuario");
                                isAuth = true;

                                mUsername = usuario.getString("nombre") + " " + usuario.getString("apellidos");

                                SharedPreferences sharedPreferences = requireContext().getSharedPreferences("myPrefs", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("username", mUsername);
                                editor.apply();

                                MainActivity mainActivity = (MainActivity) getActivity();
                                if(mainActivity != null) {
                                    mainActivity.cambiarFragmentoMain(v);
                                }

                                showToast(mensaje);

                            }else{
                                String error = response.getString("mensaje");
                                showToast(error);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            showToast("Error al procesar la respuesta del servidor");
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        hideProgressBar();
                        showToast("Error de red: " + error.getMessage());
                    }
                });

        requestQueue.add(request);

    }

    private void showToast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }

    private void showProgressBar(){
        progressBar.setVisibility(View.VISIBLE);
    }

    private void hideProgressBar(){
        progressBar.setVisibility(View.GONE);
    }
}
