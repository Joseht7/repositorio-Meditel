package com.upc.example.proyectofinal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class FragmentMain extends Fragment {

    public static final String ARG_USERNAME = "arg_username";
    private String mUsername;

    public FragmentMain(){ }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.main, container, false);

        SharedPreferences sharedPref = requireContext().getSharedPreferences("myPrefs", Context.MODE_PRIVATE);

        mUsername = sharedPref.getString("username","usuario");

        TextView textView = view.findViewById(R.id.user_name);
        textView.setText(mUsername);

        return view;
    }
}
