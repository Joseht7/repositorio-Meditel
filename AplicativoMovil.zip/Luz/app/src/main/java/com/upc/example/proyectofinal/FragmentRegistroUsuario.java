package com.upc.example.proyectofinal;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class FragmentRegistroUsuario extends Fragment {

    private EditText editTextNombre,editTextApellidos ,editTextNum_doc ,editTextCelular ,editTextFecha_nac ,editTextDomicilio ,editTextEmail ,editTextContrasena;
    private Spinner editTextTipo_doc,editTextDepartamento ,editTextProvincia ,editTextDistrito;
    private RequestQueue requestQueue;
    private Button btnGuardar;
    private String baseUrl = "http://192.168.1.59:8080/";
    private ProgressBar progressBar;
    private Boolean isAuth= false;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.registro_usuario, container, false);

        editTextNombre = rootView.findViewById(R.id.nombres);
        editTextApellidos = rootView.findViewById(R.id.apellidos);
        editTextTipo_doc = rootView.findViewById(R.id.tipo_doc);
        editTextNum_doc = rootView.findViewById(R.id.num_doc);
        editTextCelular = rootView.findViewById(R.id.celular);
        editTextFecha_nac = rootView.findViewById(R.id.fec_nac);
        editTextDepartamento = rootView.findViewById(R.id.departamento);
        editTextProvincia = rootView.findViewById(R.id.provincia);
        editTextDistrito = rootView.findViewById(R.id.distrito);
        editTextDomicilio = rootView.findViewById(R.id.domicilio);
        editTextEmail = rootView.findViewById(R.id.email);
        editTextContrasena = rootView.findViewById(R.id.contrasena);

        progressBar = rootView.findViewById(R.id.progressBar);
        requestQueue = Volley.newRequestQueue(requireContext());
        btnGuardar = rootView.findViewById(R.id.btnRegistrar);

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                guardarRegistro(view);
            }
        });
        return rootView;
    }

    private void guardarRegistro(View view) {
        String url = baseUrl + "registrar";
        JSONObject jsonBody = new JSONObject();
        try {

            jsonBody.put("nombre", editTextNombre.getText().toString().trim());
            jsonBody.put("apellidos", editTextApellidos.getText().toString().trim());
            jsonBody.put("tipo_doc", editTextTipo_doc.getSelectedItem().toString().trim());
            jsonBody.put("num_doc", editTextNum_doc.getText().toString().trim());
            jsonBody.put("celular", editTextCelular.getText().toString().trim());
            jsonBody.put("fecha_nac", editTextFecha_nac.getText().toString().trim());
            jsonBody.put("Departamento", editTextDepartamento.getSelectedItem().toString().trim());
            jsonBody.put("Provincia", editTextProvincia.getSelectedItem().toString().trim());
            jsonBody.put("Distrito", editTextDistrito.getSelectedItem().toString().trim());
            jsonBody.put("Domicilio", editTextDomicilio.getText().toString().trim());
            jsonBody.put("email", editTextEmail.getText().toString().trim());
            jsonBody.put("contrasena", editTextContrasena.getText().toString().trim());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        hideProgressBar();
                        try {
                            String mensaje = response.getString("mensaje");
                            showToast(mensaje);
                            isAuth = true;

                            MainActivity mainActivity = (MainActivity) getActivity();
                            if(mainActivity != null) {
                                mainActivity.cambiarFragmentoLogin(view);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        hideProgressBar();
                        showToast("Error al guardar registro: " + error.getMessage());
                    }
                });

        requestQueue.add(request);
    }

    private void showToast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }

    private void showProgressBar(){
        progressBar.setVisibility(View.VISIBLE);
    }

    private void hideProgressBar(){
        progressBar.setVisibility(View.GONE);
    }
}
